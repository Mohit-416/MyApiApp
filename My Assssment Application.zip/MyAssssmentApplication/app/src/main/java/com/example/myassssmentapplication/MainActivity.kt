package com.example.myassssmentapplication

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.myassssmentapplication.ApiService
import dagger.hilt.android.AndroidEntryPoint
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {
    @Inject
    lateinit var apiService: ApiService

    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var tvResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etUsername = findViewById(R.id.etUsername)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        tvResult = findViewById(R.id.tvResult)

        btnLogin.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                tvResult.text = "Please fill all fields"
                return@setOnClickListener
            }

            val request = LoginRequest(username, password)

            apiService.login(request).enqueue(object : Callback<LoginResponse> {
                override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                    if (response.isSuccessful) {
                        response.body()?.let { loginResponse ->
                            if (loginResponse.keypass != null) {
                                // Successful login
                                val keypass = loginResponse.keypass
                                tvResult.text = "Login success!"
                                val intent = Intent(this@MainActivity, DashboardActivity::class.java)
                                intent.putExtra("keypass", keypass)
                                startActivity(intent)
                            } else {
                                // Show error message from API
                                val errorMsg = loginResponse.error ?: loginResponse.message ?: "Login failed"
                                tvResult.text = errorMsg
                                Toast.makeText(this@MainActivity, errorMsg, Toast.LENGTH_LONG).show()
                            }
                        }
                    } else {
                        // Handle HTTP error responses (4xx, 5xx)
                        try {
                            val errorBody = response.errorBody()?.string()
                            val errorMsg = if (!errorBody.isNullOrEmpty()) {
                                // Try to parse the error JSON
                                try {
                                    val errorJson = JSONObject(errorBody)
                                    errorJson.getString("error") ?: errorJson.getString("message") ?: "Login failed"
                                } catch (e: Exception) {
                                    errorBody
                                }
                            } else {
                                "Login failed: ${response.code()}"
                            }
                            tvResult.text = errorMsg
                            Toast.makeText(this@MainActivity, errorMsg, Toast.LENGTH_LONG).show()
                        } catch (e: Exception) {
                            tvResult.text = "Login failed"
                            Toast.makeText(this@MainActivity, "Login failed", Toast.LENGTH_LONG).show()
                        }
                    }
                }

                override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                    val errorMsg = "Network error: ${t.message}"
                    tvResult.text = errorMsg
                    Toast.makeText(this@MainActivity, errorMsg, Toast.LENGTH_LONG).show()
                }
            })
        }
    }
}
