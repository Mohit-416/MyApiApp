package com.example.myassssmentapplication

data class LoginResponse(
    val keypass: String? = null,
    val error: String? = null,
    val message: String? = null
)