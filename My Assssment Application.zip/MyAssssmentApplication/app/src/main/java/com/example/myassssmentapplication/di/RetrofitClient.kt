package com.example.myassssmentapplication.di

import com.example.myassssmentapplication.ApiService
import com.example.myassssmentapplication.Entity
import com.example.myassssmentapplication.EntityDeserializer
import com.google.gson.GsonBuilder
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {

    private const val BASE_URL = "https://nit3213api.onrender.com/"

    // Create Gson with custom deserializer
    private val gson = GsonBuilder()
        .registerTypeAdapter(Entity::class.java, EntityDeserializer())
        .create()

    // Create Retrofit instance
    private val retrofit: Retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create(gson))
        .build()

    // Provide Retrofit instance for testing (returns Retrofit)
    fun getInstance(): Retrofit {
        return retrofit
    }

    // Provide ApiService instance for app usage
    val apiService: ApiService by lazy {
        retrofit.create(ApiService::class.java)
    }
}