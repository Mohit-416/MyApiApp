package com.example.myassssmentapplication

import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetailsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        val container = findViewById<LinearLayout>(R.id.detailsContainer)
        val entity = intent.getSerializableExtra("entity") as Entity

        entity.properties.forEach { (key, value) ->
            val title = TextView(this).apply {
                text = "$key:"
                textSize = 16f
                setTypeface(null, Typeface.BOLD)
            }

            val content = TextView(this).apply {
                text = value.toString()
                textSize = 15f
                setPadding(0, 0, 0, 12)
            }

            container.addView(title)
            container.addView(content)
        }

        // ⬅️ Back button
        findViewById<Button>(R.id.btnBack).setOnClickListener {
            finish() // finishes this activity and returns to Dashboard
        }
    }

}
