package com.example.myassssmentapplication

data class DashboardResponse(
    val entities: List<Entity>
)

