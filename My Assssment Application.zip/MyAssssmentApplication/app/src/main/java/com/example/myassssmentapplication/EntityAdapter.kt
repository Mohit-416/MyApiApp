package com.example.myassssmentapplication

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class EntityAdapter(
    private val list: List<Entity>,
    private val onClick: (Entity) -> Unit
) : RecyclerView.Adapter<EntityAdapter.EntityViewHolder>() {

    class EntityViewHolder(val layout: LinearLayout) : RecyclerView.ViewHolder(layout)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EntityViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_entity, parent, false) as LinearLayout
        return EntityViewHolder(view)
    }

    override fun onBindViewHolder(holder: EntityViewHolder, position: Int) {
        val entity = list[position]

        holder.layout.removeAllViews()

        // Show first 2 properties (or all if fewer)
        val previewProperties = entity.properties.entries.take(2)

        previewProperties.forEach { (key, value) ->
            val textView = TextView(holder.layout.context).apply {
                text = "$key: $value"
                textSize = 15f
            }
            holder.layout.addView(textView)
        }

        holder.layout.setOnClickListener {
            onClick(entity)
        }
    }

    override fun getItemCount() = list.size

}
