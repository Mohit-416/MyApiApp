package com.example.myassssmentapplication

import com.google.gson.JsonDeserializationContext
import com.google.gson.JsonDeserializer
import com.google.gson.JsonElement
import java.io.Serializable
import java.lang.reflect.Type

class EntityDeserializer : JsonDeserializer<Entity> {
    override fun deserialize(json: JsonElement, typeOfT: Type, context: JsonDeserializationContext): Entity {
        val jsonObject = json.asJsonObject
        val map = mutableMapOf<String, Serializable>()

        for ((key, value) in jsonObject.entrySet()) {
            val serializableValue: Serializable = when {
                value.isJsonPrimitive -> {
                    val prim = value.asJsonPrimitive
                    when {
                        prim.isBoolean -> prim.asBoolean as Serializable
                        prim.isNumber -> prim.asNumber as Serializable
                        prim.isString -> prim.asString as Serializable
                        else -> prim.toString() as Serializable
                    }
                }
                else -> value.toString() as Serializable
            }
            map[key] = serializableValue
        }

        return Entity(map)
    }
}
